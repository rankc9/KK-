package mybean.data;

public class BookInfo {
	private String Bname,Bprice,Bpic,Bid;;
	public BookInfo() {
		// TODO Auto-generated constructor stub
	}
	public String getBname() {
		return Bname;
	}
	public void setBname(String bname) {
		Bname = bname;
	}
	public String getBprice() {
		return Bprice;
	}
	public void setBprice(String bprice) {
		Bprice = bprice;
	}
	public String getBpic() {
		return Bpic;
	}
	public void setBpic(String bpic) {
		Bpic = bpic;
	}
	public String getBid() {
		return Bid;
	}
	public void setBid(String bid) {
		Bid = bid;
	}

}
