package mybean.data;

public class AdminInfo {
	private String aname,apassword;
	public AdminInfo() {
		// TODO Auto-generated constructor stub
	}
	public String getAname() {
		return aname;
	}
	public void setAname(String aname) {
		this.aname = aname;
	}
	public String getApassword() {
		return apassword;
	}
	public void setApassword(String apassword) {
		this.apassword = apassword;
	}
	
}
