package mybean.data;

public class Orderlist {

}
