package mybean.data;

public class Cartlist {
	private String id,Cbookname,Cprice,Cnumber,Cname,Cbookid;
	public Cartlist() {
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCbookname() {
		return Cbookname;
	}
	public void setCbookname(String cbookname) {
		Cbookname = cbookname;
	}
	public String getCprice() {
		return Cprice;
	}
	public void setCprice(String cprice) {
		Cprice = cprice;
	}
	public String getCnumber() {
		return Cnumber;
	}
	public void setCnumber(String cnumber) {
		Cnumber = cnumber;
	}
	public String getCname() {
		return Cname;
	}
	public void setCname(String cname) {
		Cname = cname;
	}
	public String getCbookid() {
		return Cbookid;
	}
	public void setCbookid(String cbookid) {
		Cbookid = cbookid;
	}
	

}
